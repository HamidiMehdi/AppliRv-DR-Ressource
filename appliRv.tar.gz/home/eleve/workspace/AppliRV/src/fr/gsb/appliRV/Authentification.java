package fr.gsb.appliRV;

import javax.swing.JFrame;

import fr.gsb.appliRV.vues.vueAuthentification;

public class Authentification {
	
	public static void main(String[] args){
		
		new vueAuthentification();

		// b34
		// c14
		
	}
}
